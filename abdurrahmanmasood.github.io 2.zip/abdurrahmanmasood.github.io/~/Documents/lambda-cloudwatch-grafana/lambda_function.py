import json
import boto3
import requests
import time
from datetime import datetime
import os

# Initialize CloudWatch client
cloudwatch = boto3.client('cloudwatch')

def lambda_handler(event, context):
    """
    Lambda function to check API health and send metrics to CloudWatch
    """
    
    # API configurations with your keys/tokens
    apis = {
        'openai': {
            'url': 'https://api.openai.com/v1/models',
            'headers': {
                'Authorization': f'Bearer {os.environ["OPENAI_API_KEY"]}',
                'Content-Type': 'application/json'
            },
            'slo': {
                'uptime': 99.5,
                'response_time': 2.0,
                'error_rate': 0.5
            }
        },
        'deepgram': {
            'url': 'https://api.deepgram.com/v1/projects',
            'headers': {
                'Authorization': f'Token {os.environ["DEEPGRAM_API_KEY"]}',
                'Content-Type': 'application/json'
            },
            'slo': {
                'uptime': 99.0,
                'response_time': 1.0,
                'error_rate': 1.0
            }
        },
        'calendar': {
            'url': 'https://www.googleapis.com/calendar/v3/users/me/calendarList',
            'headers': {
                'Authorization': f'Bearer {os.environ["GOOGLE_CALENDAR_TOKEN"]}',
                'Content-Type': 'application/json'
            },
            'slo': {
                'uptime': 99.0,
                'response_time': 3.0,
                'error_rate': 2.0
            }
        },
        'email': {
            'url': 'https://api.sendgrid.com/v3/user/profile',
            'headers': {
                'Authorization': f'Bearer {os.environ["SENDGRID_API_KEY"]}',
                'Content-Type': 'application/json'
            },
            'slo': {
                'uptime': 99.5,
                'response_time': 1.0,
                'error_rate': 0.5
            }
        },
        'filestorage': {
            'url': 'https://api.dropboxapi.com/2/users/get_current_account',
            'headers': {
                'Authorization': f'Bearer {os.environ["DROPBOX_ACCESS_TOKEN"]}',
                'Content-Type': 'application/json'
            },
            'slo': {
                'uptime': 99.9,
                'response_time': 0.5,
                'error_rate': 0.1
            }
        }
    }
    
    metrics_data = []
    
    for api_name, config in apis.items():
        try:
            # Make API call and measure response time
            start_time = time.time()
            response = requests.get(
                config['url'], 
                headers=config['headers'], 
                timeout=10
            )
            end_time = time.time()
            
            response_time = (end_time - start_time) * 1000  # Convert to milliseconds
            status_code = response.status_code
            is_success = 200 <= status_code < 300
            
            # Calculate SLO compliance
            uptime_slo_met = is_success
            response_time_slo_met = response_time <= (config['slo']['response_time'] * 1000)
            error_rate_slo_met = not is_success  # This will be 0 or 1 for individual calls
            
            # Prepare metrics for CloudWatch
            metrics_data.extend([
                {
                    'MetricName': f'{api_name}_response_time',
                    'Value': response_time,
                    'Unit': 'Milliseconds',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_uptime_slo',
                    'Value': 1 if uptime_slo_met else 0,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_response_time_slo',
                    'Value': 1 if response_time_slo_met else 0,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_error_rate_slo',
                    'Value': 0 if is_success else 1,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_status_code',
                    'Value': status_code,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                }
            ])
            
            print(f"✓ {api_name}: {status_code} - {response_time:.2f}ms")
            
        except Exception as e:
            print(f"✗ Error checking {api_name}: {str(e)}")
            # Record failure metrics
            metrics_data.extend([
                {
                    'MetricName': f'{api_name}_uptime_slo',
                    'Value': 0,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_response_time_slo',
                    'Value': 0,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                },
                {
                    'MetricName': f'{api_name}_error_rate_slo',
                    'Value': 1,
                    'Unit': 'None',
                    'Dimensions': [
                        {'Name': 'API', 'Value': api_name}
                    ]
                }
            ])
    
    # Send metrics to CloudWatch
    try:
        cloudwatch.put_metric_data(
            Namespace='API/SLO',
            MetricData=metrics_data
        )
        print(f"Successfully sent {len(metrics_data)} metrics to CloudWatch")
    except Exception as e:
        print(f"Error sending metrics to CloudWatch: {str(e)}")
        raise e
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'API health check completed',
            'metrics_sent': len(metrics_data),
            'timestamp': datetime.now().isoformat()
        })
    }


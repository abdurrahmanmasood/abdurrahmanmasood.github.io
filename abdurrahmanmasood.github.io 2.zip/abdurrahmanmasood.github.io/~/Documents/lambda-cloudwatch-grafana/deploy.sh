#!/bin/bash

# Deploy script for Lambda CloudWatch Grafana integration
# Make sure you have AWS CLI configured and have the necessary permissions

echo "🚀 Deploying Lambda function for API SLO monitoring..."

# Variables
FUNCTION_NAME="api-slo-checker"
ROLE_NAME="api-slo-lambda-role"
POLICY_NAME="api-slo-lambda-policy"
REGION="us-east-1"

# Create IAM role for Lambda
echo "📋 Creating IAM role..."
aws iam create-role \
    --role-name $ROLE_NAME \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": "lambda.amazonaws.com"
                },
                "Action": "sts:AssumeRole"
            }
        ]
    }' || echo "Role might already exist"

# Attach basic execution policy
aws iam attach-role-policy \
    --role-name $ROLE_NAME \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create custom policy for CloudWatch
echo "📋 Creating custom IAM policy..."
aws iam create-policy \
    --policy-name $POLICY_NAME \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "cloudwatch:PutMetricData",
                    "cloudwatch:GetMetricStatistics",
                    "cloudwatch:ListMetrics"
                ],
                "Resource": "*"
            }
        ]
    }' || echo "Policy might already exist"

# Attach custom policy to role
aws iam attach-role-policy \
    --role-name $ROLE_NAME \
    --policy-arn arn:aws:iam::$(aws sts get-caller-identity --query Account --output text):policy/$POLICY_NAME

# Wait for role to be ready
echo "⏳ Waiting for IAM role to be ready..."
sleep 10

# Create deployment package
echo "📦 Creating deployment package..."
pip install -r requirements.txt -t .
zip -r api-slo-checker.zip .

# Get role ARN
ROLE_ARN=$(aws iam get-role --role-name $ROLE_NAME --query 'Role.Arn' --output text)

# Create or update Lambda function
echo "🔧 Creating/updating Lambda function..."
aws lambda create-function \
    --function-name $FUNCTION_NAME \
    --runtime python3.9 \
    --role $ROLE_ARN \
    --handler lambda_function.lambda_handler \
    --zip-file fileb://api-slo-checker.zip \
    --timeout 60 \
    --memory-size 256 \
    --environment Variables='{
        "OPENAI_API_KEY":"YOUR_OPENAI_API_KEY",
        "DEEPGRAM_API_KEY":"YOUR_DEEPGRAM_API_KEY",
        "GOOGLE_CALENDAR_TOKEN":"YOUR_GOOGLE_CALENDAR_TOKEN",
        "SENDGRID_API_KEY":"YOUR_SENDGRID_API_KEY",
        "DROPBOX_ACCESS_TOKEN":"YOUR_DROPBOX_ACCESS_TOKEN"
    }' \
    --region $REGION || \
aws lambda update-function-code \
    --function-name $FUNCTION_NAME \
    --zip-file fileb://api-slo-checker.zip \
    --region $REGION

# Create CloudWatch Event Rule
echo "⏰ Creating CloudWatch Event Rule..."
aws events put-rule \
    --name "api-slo-checker-rule" \
    --schedule-expression "rate(1 minute)" \
    --description "Trigger API SLO checks every minute" \
    --region $REGION

# Add Lambda as target
FUNCTION_ARN=$(aws lambda get-function --function-name $FUNCTION_NAME --query 'Configuration.FunctionArn' --output text)
aws events put-targets \
    --rule "api-slo-checker-rule" \
    --targets "Id"="1","Arn"="$FUNCTION_ARN" \
    --region $REGION

# Add permission for EventBridge to invoke Lambda
aws lambda add-permission \
    --function-name $FUNCTION_NAME \
    --statement-id "allow-eventbridge" \
    --action "lambda:InvokeFunction" \
    --principal events.amazonaws.com \
    --source-arn "arn:aws:events:$REGION:$(aws sts get-caller-identity --query Account --output text):rule/api-slo-checker-rule" \
    --region $REGION

echo "✅ Deployment complete!"
echo "📊 Lambda function: $FUNCTION_NAME"
echo "⏰ Event rule: api-slo-checker-rule"
echo "📈 CloudWatch namespace: API/SLO"
echo ""
echo "🔧 Next steps:"
echo "1. Update environment variables in Lambda with your actual API keys"
echo "2. Configure Grafana CloudWatch data source"
echo "3. Import the provided dashboard JSON"
echo "4. Test the function manually or wait for the scheduled trigger"


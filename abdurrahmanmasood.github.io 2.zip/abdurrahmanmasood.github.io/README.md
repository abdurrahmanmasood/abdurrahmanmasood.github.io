# Resume

<https://abdurrahmanmasood.github.io/>
